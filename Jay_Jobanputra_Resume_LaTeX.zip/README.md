﻿# Jay Jobanputra — Resume (LaTeX)

## Compile
pdflatex Jay_Jobanputra_Resume.tex

## Contents
- Jay_Jobanputra_Resume.tex — source
- Jay_Jobanputra_Resume.pdf — built PDF (2 pages)

Requires a standard TeX distribution (MiKTeX / TeX Live).
